/// Copyright (c) 2023  Ward van der Veer

use serde::{Serialize, Deserialize};
use json_schema_parser::*;


json_schema_file!("src/random_user/random_user_schema.json", "->People");

/// Copyright (c) 2023  Ward van der Veer
extern crate serde;
extern crate serde_json;
extern crate json_schema_parser;

mod random_user;

use std::fs;
use random_user::*;

// This example data supplied by https://randomuser.me

fn main() {
    let file_path: String = "sample_data.json".to_string();
    let contents: String = fs::read_to_string(file_path)
        .expect("Could not read sample data\n");
    
    let people: People = serde_json::from_str(&contents).unwrap();

    let person = people.results[0].clone();

    println!("{}", person.email);
}
